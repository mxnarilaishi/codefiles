﻿=== Kawaii Cute Little Bear Cursor Set ===

By: ツ☪ NaLexnu ♡♥ (http://www.rw-designer.com/user/38152) mlopez1662@hotmail.com

Download: http://www.rw-designer.com/cursor-set/kawaiilitbearmimidestino

Author's description:

 ツ MIMI DESTINO ♥.♡ 

Enjoy the set.
Thanks for download and review. 

--.

How to install?
https://youtu.be/VOr3HZHS4fQ

Como instalarlos?
https://youtu.be/EGx6plXI0Yc

Have any cursor requests? feel free to comment on my profile!
or here http://www.rw-designer.com/entry/3308

social networks --> http://www.rw-designer.com/entry/3309

 ..''..''..


Credits -- Creditos
http://purinrii.deviantart.com/art/Animated-Bear-Bullet-Free-To-Use-424992099

 

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.